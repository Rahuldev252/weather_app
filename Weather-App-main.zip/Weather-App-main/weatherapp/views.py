from django.shortcuts import render
from django.contrib import messages
import requests
import datetime

def home(request):
    if 'city' in request.POST:
        city = request.POST['city']
    else:
        city = 'indore'

    openweather_api_key = '43f2cf69a809fcae981d992af3fdd02e'
    google_custom_search_key = 'AIzaSyCukhXwcoW9raIPXzg_4b9HHkbDiaTnMz0'
    google_custom_search_cx = 'b719ba9da003842f0'

    # Get weather data
    weather_url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={openweather_api_key}'
    weather_params = {'units': 'metric'}
    weather_response = requests.get(weather_url, params=weather_params)

    # Get city image
    city_query = f'{city} 1920x1080'
    city_search_url = f"https://www.googleapis.com/customsearch/v1?key={google_custom_search_key}&cx={google_custom_search_cx}&q={city_query}&searchType=image&imgSize=xlarge"
    city_search_response = requests.get(city_search_url).json()
    image_url = None

    if 'items' in city_search_response:
        items = city_search_response['items']
        if items:
            image_url = items[1]['link']

    try:
        weather_data = weather_response.json()
        description = weather_data['weather'][0]['description']
        icon = weather_data['weather'][0]['icon']
        temp = weather_data['main']['temp']
        day = datetime.date.today()

        return render(request, 'weatherapp/index.html', {
            'description': description,
            'icon': icon,
            'temp': temp,
            'day': day,
            'city': city,
            'exception_occurred': False,
            'image_url': image_url,
        
        })

    except KeyError:
        exception_occurred = True
        messages.error(request, 'Entered data is not available in the API')
        day = datetime.date.today()

        return render(request, 'weatherapp/index.html', {
            'description': 'clear sky',
            'icon': '01d',
            'temp': 25,
            'day': day,
            'city': 'indore',
            'exception_occurred': exception_occurred,
            'image_url': image_url,
        })
